﻿
namespace BLAGfond
{
    partial class dobavitrabotnika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Submit_b = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.PasswordInput = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.LoginInput = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RabotnickRoleComboBox = new System.Windows.Forms.ComboBox();
            this.FullNameInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Submit_b
            // 
            this.Submit_b.BackColor = System.Drawing.Color.LightBlue;
            this.Submit_b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Submit_b.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.Submit_b.Location = new System.Drawing.Point(136, 130);
            this.Submit_b.Name = "Submit_b";
            this.Submit_b.Size = new System.Drawing.Size(241, 44);
            this.Submit_b.TabIndex = 8;
            this.Submit_b.Text = "Добавить";
            this.Submit_b.UseVisualStyleBackColor = false;
            this.Submit_b.Click += new System.EventHandler(this.Submit_b_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.label4.Location = new System.Drawing.Point(360, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 30);
            this.label4.TabIndex = 7;
            this.label4.Text = "Роль";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // PasswordInput
            // 
            this.PasswordInput.Location = new System.Drawing.Point(259, 104);
            this.PasswordInput.Name = "PasswordInput";
            this.PasswordInput.PasswordChar = '*';
            this.PasswordInput.Size = new System.Drawing.Size(241, 20);
            this.PasswordInput.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.label3.Location = new System.Drawing.Point(344, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 30);
            this.label3.TabIndex = 5;
            this.label3.Text = "Пароль";
            // 
            // LoginInput
            // 
            this.LoginInput.Location = new System.Drawing.Point(12, 104);
            this.LoginInput.Name = "LoginInput";
            this.LoginInput.Size = new System.Drawing.Size(241, 20);
            this.LoginInput.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.label2.Location = new System.Drawing.Point(98, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 30);
            this.label2.TabIndex = 3;
            this.label2.Text = "Логин";
            // 
            // RabotnickRoleComboBox
            // 
            this.RabotnickRoleComboBox.FormattingEnabled = true;
            this.RabotnickRoleComboBox.Items.AddRange(new object[] {
            "admin",
            "Rabotnick"});
            this.RabotnickRoleComboBox.Location = new System.Drawing.Point(259, 45);
            this.RabotnickRoleComboBox.Name = "RabotnickRoleComboBox";
            this.RabotnickRoleComboBox.Size = new System.Drawing.Size(241, 21);
            this.RabotnickRoleComboBox.TabIndex = 2;
            // 
            // FullNameInput
            // 
            this.FullNameInput.Location = new System.Drawing.Point(12, 45);
            this.FullNameInput.Name = "FullNameInput";
            this.FullNameInput.Size = new System.Drawing.Size(241, 20);
            this.FullNameInput.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.label1.Location = new System.Drawing.Point(105, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "ФИО";
            // 
            // dobavitrabotnika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(509, 190);
            this.Controls.Add(this.Submit_b);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.PasswordInput);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LoginInput);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RabotnickRoleComboBox);
            this.Controls.Add(this.FullNameInput);
            this.Controls.Add(this.label1);
            this.Name = "dobavitrabotnika";
            this.Text = "Добавить работника";
            this.Load += new System.EventHandler(this.RabotnickAddForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FullNameInput;
        private System.Windows.Forms.ComboBox RabotnickRoleComboBox;
        private System.Windows.Forms.TextBox LoginInput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PasswordInput;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Submit_b;
    }
}