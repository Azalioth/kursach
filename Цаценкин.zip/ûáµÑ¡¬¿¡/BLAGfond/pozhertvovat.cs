﻿using BLAGfond.DataBas;
using BLAGfond;
using BLAGfond.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLAGfond
{
    
    public partial class pozhertvovat : shablon
    {

        List<TovarInCart> cart = new List<TovarInCart>();

        public pozhertvovat()
        {
            InitializeComponent();

           
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            DataBaseControl dbController = new DataBaseControl();
            List<Tovar> tovars = dbController.GetTovars();
            for(int i = 0; i<tovars.Count; i++)
            {
                TovarsGridView.Rows.Add(tovars[i].id,tovars[i].title,tovars[i].price,"1","Пожертвовать") ;
            }
        }

        private void TovarListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
      

            
        }

        private void TovarsGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataBaseControl dbController = new DataBaseControl();
            if (e.ColumnIndex == 4)
            {
                int tovarId = Convert.ToInt32(TovarsGridView.Rows[e.RowIndex].Cells[0].Value);
                int count = Convert.ToInt32(TovarsGridView.Rows[e.RowIndex].Cells[3].Value);
                if (count < 1)
                {
                    MessageBox.Show("Некорректная самму пожертвования");
                    return;
                }
                Tovar tovar = dbController.GetTovarById(tovarId);

                for (int i = 0; i < cart.Count; i++)
                {
                    if (cart[i].tovar.id == tovarId)
                    {
                        if(cart[i].count+count > tovar.count)
                        {
                            MessageBox.Show($"Жертвовать такую сумму нет необходимости ({count}) ");
                            return;
                        }
                        cart[i].count+= count;
                        DisplayCart();
                        return;
                    }
                }

                if (count > tovar.count)
                {
                    MessageBox.Show($"Жертвовать такую сумму нет необходимости ({count})");
                    return;
                }
                TovarInCart newTovar = new TovarInCart();
                newTovar.tovar = tovar; 
                newTovar.count = count;
                cart.Add(newTovar);
                DisplayCart();

            }
        }

        private void DisplayCart()
        {
            CartGridView.Rows.Clear();
            double totalSum = 0;
            
            for(int i = 0; i<cart.Count; i++)
            {
                CartGridView.Rows.Add(cart[i].tovar.title, cart[i].count, cart[i].tovar.price * cart[i].count);
                totalSum += cart[i].tovar.price * cart[i].count;
            }
            try
            {
                SummOrderNumeric.Value = (decimal)totalSum;
            }
            catch (Exception) { }


        }

        private void SummOrderNumeric_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataBaseControl dbController = new DataBaseControl();

            Order order = new Order();
            order.tovars = cart;
            dbController.AddOrder(order);
            this.Close();

            pechat form = new pechat(order);
            form.Show();

        }

    }

    public class TovarInCart
    {
        public Tovar tovar;
        public int count;
    }

}
