﻿
namespace BLAGfond
{
    partial class pozhertvovat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.SummOrderNumeric = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TovarsGridView = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BuyButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.CartGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.SummOrderNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TovarsGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CartGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe Script", 12F);
            this.button2.Location = new System.Drawing.Point(263, 448);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(203, 60);
            this.button2.TabIndex = 7;
            this.button2.Text = "пожертвовать";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // SummOrderNumeric
            // 
            this.SummOrderNumeric.Font = new System.Drawing.Font("Segoe Script", 8.25F);
            this.SummOrderNumeric.Increment = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SummOrderNumeric.InterceptArrowKeys = false;
            this.SummOrderNumeric.Location = new System.Drawing.Point(310, 416);
            this.SummOrderNumeric.Maximum = new decimal(new int[] {
            1661992959,
            1808227885,
            5,
            0});
            this.SummOrderNumeric.Name = "SummOrderNumeric";
            this.SummOrderNumeric.ReadOnly = true;
            this.SummOrderNumeric.Size = new System.Drawing.Size(120, 25);
            this.SummOrderNumeric.TabIndex = 8;
            this.SummOrderNumeric.TabStop = false;
            this.SummOrderNumeric.ValueChanged += new System.EventHandler(this.SummOrderNumeric_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe Script", 14.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(221, 383);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(320, 31);
            this.label3.TabIndex = 9;
            this.label3.Text = "Стоимость пожертвования";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe Script", 14.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(220, 194);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(321, 31);
            this.label4.TabIndex = 10;
            this.label4.Text = "Суммарные пожертвования";
            // 
            // TovarsGridView
            // 
            this.TovarsGridView.AllowUserToAddRows = false;
            this.TovarsGridView.AllowUserToDeleteRows = false;
            this.TovarsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TovarsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TovarsGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.title,
            this.Price,
            this.Count,
            this.BuyButton});
            this.TovarsGridView.Location = new System.Drawing.Point(24, 41);
            this.TovarsGridView.Name = "TovarsGridView";
            this.TovarsGridView.Size = new System.Drawing.Size(687, 150);
            this.TovarsGridView.TabIndex = 11;
            this.TovarsGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TovarsGridView_CellContentClick);
            // 
            // Id
            // 
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // title
            // 
            this.title.HeaderText = "Имя нуждающегося";
            this.title.Name = "title";
            this.title.ReadOnly = true;
            // 
            // Price
            // 
            this.Price.HeaderText = "Курс валюты для пожертвования ";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            // 
            // Count
            // 
            this.Count.HeaderText = "Сумма пожертвования";
            this.Count.Name = "Count";
            // 
            // BuyButton
            // 
            this.BuyButton.HeaderText = "Пожертвовать";
            this.BuyButton.Name = "BuyButton";
            this.BuyButton.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.BuyButton.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 14.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(243, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 31);
            this.label1.TabIndex = 12;
            this.label1.Text = "Список нуждающихся";
            // 
            // CartGridView
            // 
            this.CartGridView.AllowUserToAddRows = false;
            this.CartGridView.AllowUserToDeleteRows = false;
            this.CartGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CartGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CartGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn2});
            this.CartGridView.Location = new System.Drawing.Point(24, 230);
            this.CartGridView.Name = "CartGridView";
            this.CartGridView.Size = new System.Drawing.Size(687, 150);
            this.CartGridView.TabIndex = 13;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Имя нуждающегося";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Сумма пожертвования";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Общая сумма(в рублях)";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 520);
            this.Controls.Add(this.CartGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TovarsGridView);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.SummOrderNumeric);
            this.Controls.Add(this.button2);
            this.Name = "OrderForm";
            this.Text = "Пожертвовать";
            this.Load += new System.EventHandler(this.OrderForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SummOrderNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TovarsGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CartGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown SummOrderNumeric;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView TovarsGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView CartGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn title;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Count;
        private System.Windows.Forms.DataGridViewButtonColumn BuyButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}