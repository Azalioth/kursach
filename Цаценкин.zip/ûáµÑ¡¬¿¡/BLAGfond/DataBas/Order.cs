﻿using BLAGfond.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLAGfond.DataBas
{
    public class Order
    {
        public int id;
        public List<TovarInCart> tovars;
    }
}
