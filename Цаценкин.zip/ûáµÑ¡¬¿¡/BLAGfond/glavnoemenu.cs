﻿using BLAGfond;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLAGfond
{
    public partial class glavnoemenu : shablon
    {
        public glavnoemenu()
        {
            InitializeComponent();
            DataBaseControl dbController = new DataBaseControl();
            dbController.LoadDataBase();
        }

        private void MainMenuForm_Load(object sender, EventArgs e)
        {

        }

        private void Rabotnick_b_Click(object sender, EventArgs e)
        {
            auth form = new auth();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void Client_b_Click(object sender, EventArgs e)
        {
            pozhertvovat form = new pozhertvovat();
            this.Hide();
            form.Show();
            form.Owner = this;
        }
    }
}
