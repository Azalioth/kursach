﻿
namespace BLAGfond
{
    partial class spisokrabotnikov
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SearchInput = new System.Windows.Forms.TextBox();
            this.RabotnicksGridView = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Login = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RabotnickRole = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.EditButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DeleteButton = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.RabotnicksGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // SearchInput
            // 
            this.SearchInput.Location = new System.Drawing.Point(474, 12);
            this.SearchInput.Name = "SearchInput";
            this.SearchInput.Size = new System.Drawing.Size(144, 20);
            this.SearchInput.TabIndex = 1;
            this.SearchInput.TextChanged += new System.EventHandler(this.SearchInput_TextChanged);
            // 
            // RabotnicksGridView
            // 
            this.RabotnicksGridView.AllowUserToAddRows = false;
            this.RabotnicksGridView.AllowUserToDeleteRows = false;
            this.RabotnicksGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.RabotnicksGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RabotnicksGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.FullName,
            this.Login,
            this.Password,
            this.RabotnickRole,
            this.EditButton,
            this.DeleteButton});
            this.RabotnicksGridView.Location = new System.Drawing.Point(12, 38);
            this.RabotnicksGridView.Name = "RabotnicksGridView";
            this.RabotnicksGridView.Size = new System.Drawing.Size(1057, 435);
            this.RabotnicksGridView.TabIndex = 0;
            this.RabotnicksGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.RabotnicksGridView_CellContentClick);
            this.RabotnicksGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.UsersGridView_CellMouseClick);
            // 
            // id
            // 
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // FullName
            // 
            this.FullName.HeaderText = "ФИО";
            this.FullName.Name = "FullName";
            this.FullName.ReadOnly = true;
            // 
            // Login
            // 
            this.Login.HeaderText = "Логин";
            this.Login.Name = "Login";
            this.Login.ReadOnly = true;
            // 
            // Password
            // 
            this.Password.HeaderText = "Пароль";
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            // 
            // RabotnickRole
            // 
            this.RabotnickRole.HeaderText = "Роль";
            this.RabotnickRole.Items.AddRange(new object[] {
            "user",
            "admin",
            "Rabotnick"});
            this.RabotnickRole.Name = "RabotnickRole";
            this.RabotnickRole.ReadOnly = true;
            // 
            // EditButton
            // 
            this.EditButton.HeaderText = "Edit";
            this.EditButton.Name = "EditButton";
            // 
            // DeleteButton
            // 
            this.DeleteButton.HeaderText = "Delete";
            this.DeleteButton.Name = "DeleteButton";
            // 
            // UsersGridViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 485);
            this.Controls.Add(this.SearchInput);
            this.Controls.Add(this.RabotnicksGridView);
            this.Name = "UsersGridViewForm";
            this.Text = "Список сотрудников";
            this.Load += new System.EventHandler(this.UsersGridViewForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.RabotnicksGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView RabotnicksGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn FullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Login;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewComboBoxColumn RabotnickRole;
        private System.Windows.Forms.DataGridViewButtonColumn EditButton;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteButton;
        private System.Windows.Forms.TextBox SearchInput;
    }
}