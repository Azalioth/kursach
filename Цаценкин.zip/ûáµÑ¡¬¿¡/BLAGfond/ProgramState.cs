﻿using BLAGfond.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLAGfond
{
   
    class ProgramState
    {
        private static Rabotnick1 AuthorizedUser;

        public void setAuthorizedUser(Rabotnick1 user)
        {
            AuthorizedUser = user;
        }
        public void AuthorizedUserLogout()
        {
            AuthorizedUser = null;
        }
         
        public Rabotnick1 GetAuthorizedUser()
        {
            return AuthorizedUser;
        }
    }
}
