﻿using BLAGfond;
using BLAGfond.DataBase;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLAGfond
{
    public partial class menurabotnika : shablon
    {
        public menurabotnika()
        {
            InitializeComponent();
            ProgramState pState = new ProgramState();
            Rabotnick1 authorizedUser = pState.GetAuthorizedUser();
            if (authorizedUser.RabotnickRole == Rabotnick1.role.Rabotnick)
            {
                AddTovar_b.Visible = false;
                GridView_b.Visible = false;
                AddRabotnick_b.Visible = false;
                
            }

        }

        private void RabotnickMenuForm_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dobavitrabotnika form = new dobavitrabotnika();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            spisokrabotnikov form = new spisokrabotnikov();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            spisoknuzhdaushihsa form = new spisoknuzhdaushihsa();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dobavitnuzhdaushegodsa form = new dobavitnuzhdaushegodsa();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pozhertvovat form = new pozhertvovat();
            this.Hide();
            form.Show();
            form.Owner = this;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            istoriapozhertvovanii form = new istoriapozhertvovanii();
            this.Hide();
            form.Show();
            form.Owner = this;
        }
    }
}
