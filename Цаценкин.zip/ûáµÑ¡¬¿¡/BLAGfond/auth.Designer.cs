﻿
namespace BLAGfond
{
    partial class auth
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.LoginInput = new System.Windows.Forms.TextBox();
            this.PasswordInput = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Submit_b = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.label1.Location = new System.Drawing.Point(198, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Логин\r\n";
            // 
            // LoginInput
            // 
            this.LoginInput.Location = new System.Drawing.Point(131, 130);
            this.LoginInput.Name = "LoginInput";
            this.LoginInput.Size = new System.Drawing.Size(231, 20);
            this.LoginInput.TabIndex = 1;
            this.LoginInput.TextChanged += new System.EventHandler(this.LoginInput_TextChanged);
            // 
            // PasswordInput
            // 
            this.PasswordInput.Location = new System.Drawing.Point(131, 186);
            this.PasswordInput.Name = "PasswordInput";
            this.PasswordInput.PasswordChar = '*';
            this.PasswordInput.Size = new System.Drawing.Size(231, 20);
            this.PasswordInput.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.label2.Location = new System.Drawing.Point(198, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 30);
            this.label2.TabIndex = 2;
            this.label2.Text = "Пароль";
            // 
            // Submit_b
            // 
            this.Submit_b.BackColor = System.Drawing.Color.LightBlue;
            this.Submit_b.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Submit_b.Font = new System.Drawing.Font("Segoe Script", 14.25F);
            this.Submit_b.Location = new System.Drawing.Point(103, 335);
            this.Submit_b.Name = "Submit_b";
            this.Submit_b.Size = new System.Drawing.Size(278, 43);
            this.Submit_b.TabIndex = 4;
            this.Submit_b.Text = "Войти";
            this.Submit_b.UseVisualStyleBackColor = false;
            this.Submit_b.Click += new System.EventHandler(this.Submit_b_Click);
            // 
            // RabotnickAuthorizationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 390);
            this.Controls.Add(this.Submit_b);
            this.Controls.Add(this.PasswordInput);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LoginInput);
            this.Controls.Add(this.label1);
            this.Name = "RabotnickAuthorizationForm";
            this.Text = "Авторизация работника";
            this.Load += new System.EventHandler(this.RabotnickAuthorizationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox LoginInput;
        private System.Windows.Forms.TextBox PasswordInput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Submit_b;
    }
}