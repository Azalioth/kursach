﻿using BLAGfond;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BLAGfond
{
    public partial class auth : shablon
    {
        public auth()
        {
            InitializeComponent();
        }

        private void RabotnickAuthorizationForm_Load(object sender, EventArgs e)
        {

        }

        private void Submit_b_Click(object sender, EventArgs e)
        {
            DataBaseControl dbController = new DataBaseControl();

            string login = LoginInput.Text.Trim();
            string password = PasswordInput.Text.Trim();
            if (login != "" && password != "")
            {
                try
                {
                    dbController.AuthorizateUser(login, password);
                    menurabotnika form = new menurabotnika();
                    form.Owner = this.Owner;
                    form.Show();
                    this.Owner = null;
                    this.Close();
                }
                catch
                {
                    MessageBox.Show("Неверный логин или пароль");
                    PasswordInput.Text = "";
                }
            }
        }

        private void LoginInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
